import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Search, Filter, MoreVertical, FileText, Download, Share2, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";

const documents = [
  { id: "1", name: "Q4 Financial Report.pdf", owner: "Sarah Johnson", date: "2024-01-15", size: "2.4 MB", status: "Approved", tags: ["Finance", "Q4"] },
  { id: "2", name: "Marketing Strategy 2024.docx", owner: "Michael Chen", date: "2024-01-14", size: "1.8 MB", status: "Pending", tags: ["Marketing"] },
  { id: "3", name: "Project Proposal.pdf", owner: "Emma Wilson", date: "2024-01-13", size: "3.2 MB", status: "Approved", tags: ["Project"] },
  { id: "4", name: "Team Meeting Notes.docx", owner: "James Brown", date: "2024-01-12", size: "512 KB", status: "Draft", tags: ["Meeting"] },
  { id: "5", name: "Design Assets.zip", owner: "Lisa Anderson", date: "2024-01-11", size: "15.6 MB", status: "Approved", tags: ["Design"] },
  { id: "6", name: "Annual Report 2023.pdf", owner: "David Lee", date: "2024-01-10", size: "4.8 MB", status: "Approved", tags: ["Finance", "Annual"] },
];

export default function Documents() {
  const [searchQuery, setSearchQuery] = useState("");

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Approved":
        return "bg-accent/10 text-accent hover:bg-accent/20";
      case "Pending":
        return "bg-yellow-500/10 text-yellow-600 hover:bg-yellow-500/20";
      case "Draft":
        return "bg-muted text-muted-foreground hover:bg-muted";
      default:
        return "";
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Documents</h1>
          <p className="text-muted-foreground mt-1">Manage and organize your documents</p>
        </div>
        <Button>Upload Document</Button>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search documents..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Button variant="outline">
              <Filter className="mr-2 h-4 w-4" />
              Filters
            </Button>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Owner</TableHead>
                <TableHead>Date Modified</TableHead>
                <TableHead>Size</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Tags</TableHead>
                <TableHead className="w-[50px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {documents.map((doc) => (
                <TableRow key={doc.id} className="hover:bg-muted/50">
                  <TableCell>
                    <Link to={`/documents/${doc.id}`} className="flex items-center gap-2 hover:text-primary">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium">{doc.name}</span>
                    </Link>
                  </TableCell>
                  <TableCell>{doc.owner}</TableCell>
                  <TableCell>{doc.date}</TableCell>
                  <TableCell>{doc.size}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className={getStatusColor(doc.status)}>
                      {doc.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      {doc.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-popover">
                        <DropdownMenuItem>
                          <Download className="mr-2 h-4 w-4" />
                          Download
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Share2 className="mr-2 h-4 w-4" />
                          Share
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive">
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
