import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Download, Share2, Trash2, Edit, FileText, Calendar, User, Tag } from "lucide-react";

export default function DocumentDetail() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Q4 Financial Report.pdf</h1>
          <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
            <span className="flex items-center gap-1">
              <User className="h-4 w-4" />
              Sarah Johnson
            </span>
            <span className="flex items-center gap-1">
              <Calendar className="h-4 w-4" />
              January 15, 2024
            </span>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Download
          </Button>
          <Button variant="outline">
            <Share2 className="mr-2 h-4 w-4" />
            Share
          </Button>
          <Button variant="outline">
            <Edit className="mr-2 h-4 w-4" />
            Edit
          </Button>
          <Button variant="outline" className="text-destructive">
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Document Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="aspect-[3/4] bg-muted rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">PDF Preview</p>
                  <p className="text-sm text-muted-foreground mt-1">2.4 MB • 24 pages</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Version History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { version: "v1.3", author: "Sarah Johnson", date: "Jan 15, 2024", changes: "Updated financial figures" },
                  { version: "v1.2", author: "Michael Chen", date: "Jan 14, 2024", changes: "Added Q4 summary" },
                  { version: "v1.1", author: "Sarah Johnson", date: "Jan 10, 2024", changes: "Initial draft" },
                ].map((version, index) => (
                  <div key={index} className="flex justify-between items-start pb-4 border-b last:border-0">
                    <div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{version.version}</Badge>
                        <span className="text-sm font-medium">{version.author}</span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{version.changes}</p>
                      <p className="text-xs text-muted-foreground mt-1">{version.date}</p>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="text-sm font-medium mb-2">Status</div>
                <Badge className="bg-accent/10 text-accent hover:bg-accent/20">Approved</Badge>
              </div>
              <Separator />
              <div>
                <div className="text-sm font-medium mb-2">Tags</div>
                <div className="flex flex-wrap gap-1">
                  <Badge variant="outline">Finance</Badge>
                  <Badge variant="outline">Q4</Badge>
                  <Badge variant="outline">2024</Badge>
                </div>
              </div>
              <Separator />
              <div>
                <div className="text-sm font-medium mb-2">File Information</div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Size</span>
                    <span>2.4 MB</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Pages</span>
                    <span>24</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Format</span>
                    <span>PDF</span>
                  </div>
                </div>
              </div>
              <Separator />
              <div>
                <div className="text-sm font-medium mb-2">Access</div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Created</span>
                    <span>Jan 10, 2024</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Modified</span>
                    <span>Jan 15, 2024</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Views</span>
                    <span>47</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Comments</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { author: "Michael Chen", comment: "Looks great! Ready to share.", time: "2 hours ago" },
                  { author: "Emma Wilson", comment: "Please update the Q3 comparison.", time: "1 day ago" },
                ].map((comment, index) => (
                  <div key={index} className="pb-4 border-b last:border-0">
                    <div className="flex items-start gap-2">
                      <div className="rounded-full bg-primary/10 p-2">
                        <User className="h-4 w-4 text-primary" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">{comment.author}</span>
                          <span className="text-xs text-muted-foreground">{comment.time}</span>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">{comment.comment}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
