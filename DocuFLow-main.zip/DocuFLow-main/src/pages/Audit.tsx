import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Search, Download } from "lucide-react";

const logs = [
  { id: "1", user: "Sarah Johnson", action: "Upload", document: "Q4 Financial Report.pdf", date: "2024-01-15 14:23", ip: "192.168.1.100" },
  { id: "2", user: "Michael Chen", action: "Approve", document: "Marketing Strategy.docx", date: "2024-01-15 13:45", ip: "192.168.1.101" },
  { id: "3", user: "Emma Wilson", action: "Download", document: "Project Proposal.pdf", date: "2024-01-15 12:30", ip: "192.168.1.102" },
  { id: "4", user: "James Brown", action: "Share", document: "Team Meeting Notes.docx", date: "2024-01-15 11:15", ip: "192.168.1.103" },
  { id: "5", user: "Lisa Anderson", action: "Delete", document: "Old Draft.pdf", date: "2024-01-15 10:00", ip: "192.168.1.104" },
];

export default function Audit() {
  const getActionColor = (action: string) => {
    switch (action) {
      case "Upload":
        return "bg-primary/10 text-primary";
      case "Approve":
        return "bg-accent/10 text-accent";
      case "Delete":
        return "bg-destructive/10 text-destructive";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Audit Logs</h1>
          <p className="text-muted-foreground mt-1">Track all document activities and user actions</p>
        </div>
        <Button variant="outline">
          <Download className="mr-2 h-4 w-4" />
          Export Logs
        </Button>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Search logs..." className="pl-9" />
            </div>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Action</TableHead>
                <TableHead>Document</TableHead>
                <TableHead>Date & Time</TableHead>
                <TableHead>IP Address</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.map((log) => (
                <TableRow key={log.id} className="hover:bg-muted/50">
                  <TableCell className="font-medium">{log.user}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className={getActionColor(log.action)}>
                      {log.action}
                    </Badge>
                  </TableCell>
                  <TableCell>{log.document}</TableCell>
                  <TableCell className="text-muted-foreground">{log.date}</TableCell>
                  <TableCell className="text-muted-foreground font-mono text-sm">{log.ip}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
