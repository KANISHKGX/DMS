import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, CheckCircle, XCircle } from "lucide-react";

const workflows = [
  {
    id: "1",
    document: "Marketing Strategy 2024.docx",
    submittedBy: "Michael Chen",
    date: "2024-01-14",
    status: "Pending",
    step: "Manager Approval",
  },
  {
    id: "2",
    document: "Budget Proposal Q1.xlsx",
    submittedBy: "Sarah Johnson",
    date: "2024-01-13",
    status: "Pending",
    step: "Finance Review",
  },
  {
    id: "3",
    document: "Contract Agreement.pdf",
    submittedBy: "Emma Wilson",
    date: "2024-01-12",
    status: "Approved",
    step: "Final",
  },
];

export default function Workflows() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Workflows & Approvals</h1>
        <p className="text-muted-foreground mt-1">Review and manage document approval requests</p>
      </div>

      <div className="grid gap-4">
        {workflows.map((workflow) => (
          <Card key={workflow.id} className="hover-lift">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-3">
                    <h3 className="text-lg font-semibold">{workflow.document}</h3>
                    <Badge
                      variant="secondary"
                      className={
                        workflow.status === "Pending"
                          ? "bg-yellow-500/10 text-yellow-600"
                          : "bg-accent/10 text-accent"
                      }
                    >
                      {workflow.status}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span>Submitted by {workflow.submittedBy}</span>
                    <span>•</span>
                    <span>{workflow.date}</span>
                    <span>•</span>
                    <span>Current: {workflow.step}</span>
                  </div>
                </div>
                {workflow.status === "Pending" && (
                  <div className="flex gap-2">
                    <Button variant="outline" className="text-accent">
                      <CheckCircle className="mr-2 h-4 w-4" />
                      Approve
                    </Button>
                    <Button variant="outline" className="text-destructive">
                      <XCircle className="mr-2 h-4 w-4" />
                      Reject
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
